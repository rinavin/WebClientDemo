
import { Component, ViewEncapsulation } from '@angular/core';



@Component({
  selector: 'app',
  templateUrl: './app.component.html',
  styleUrls: ['./css/groot-material.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent {

}
